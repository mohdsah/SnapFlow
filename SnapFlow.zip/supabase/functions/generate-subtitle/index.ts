// ============================================================
//  SNAPFLOW — Edge Function: AI Subtitle Generator (Whisper)
//  Deploy: npx supabase functions deploy generate-subtitle
//  Secret: OPENAI_API_KEY (untuk Whisper API)
// ============================================================

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') {
        return new Response(null, {
            headers: {
                'Access-Control-Allow-Origin':  '*',
                'Access-Control-Allow-Methods': 'POST',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            }
        });
    }

    try {
        const formData  = await req.formData();
        const audioFile = formData.get('audio') as File;
        const language  = (formData.get('language') as string) || 'ms'; // ms = Bahasa Melayu

        if (!audioFile) {
            return new Response(JSON.stringify({ error: 'Tiada fail audio.' }), { status: 400 });
        }

        const OPENAI_KEY = Deno.env.get('OPENAI_API_KEY')!;

        // Hantar ke Whisper API
        const whisperForm = new FormData();
        whisperForm.append('file',             audioFile, audioFile.name || 'audio.webm');
        whisperForm.append('model',            'whisper-1');
        whisperForm.append('language',         language);
        whisperForm.append('response_format',  'verbose_json');
        whisperForm.append('timestamp_granularities[]', 'word');

        const whisperRes = await fetch('https://api.openai.com/v1/audio/transcriptions', {
            method:  'POST',
            headers: { 'Authorization': `Bearer ${OPENAI_KEY}` },
            body:    whisperForm,
        });

        if (!whisperRes.ok) {
            const errText = await whisperRes.text();
            throw new Error(`Whisper API error: ${errText}`);
        }

        const whisperData = await whisperRes.json();

        // Convert segments ke format SRT
        const segments = whisperData.segments || [];
        const srt = segments.map((seg: any, i: number) => {
            const start = formatSRTTime(seg.start);
            const end   = formatSRTTime(seg.end);
            return `${i + 1}\n${start} --> ${end}\n${seg.text.trim()}\n`;
        }).join('\n');

        // Juga return sebagai array untuk overlay dalam app
        const subtitles = segments.map((seg: any) => ({
            start:   seg.start,
            end:     seg.end,
            text:    seg.text.trim(),
        }));

        return new Response(JSON.stringify({
            srt,
            subtitles,
            fullText: whisperData.text,
            language: whisperData.language,
            duration: whisperData.duration,
        }), {
            headers: {
                'Content-Type':                'application/json',
                'Access-Control-Allow-Origin': '*',
            }
        });

    } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), {
            status:  500,
            headers: {
                'Content-Type':                'application/json',
                'Access-Control-Allow-Origin': '*',
            }
        });
    }
});

function formatSRTTime(seconds: number): string {
    const h   = Math.floor(seconds / 3600);
    const m   = Math.floor((seconds % 3600) / 60);
    const s   = Math.floor(seconds % 60);
    const ms  = Math.round((seconds % 1) * 1000);
    return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')},${String(ms).padStart(3,'0')}`;
}
