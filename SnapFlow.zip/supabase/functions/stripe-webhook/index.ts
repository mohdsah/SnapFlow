// ============================================================
//  SNAPFLOW — Edge Function: Stripe Webhook
//  Deploy: npx supabase functions deploy stripe-webhook
//  Stripe Dashboard → Webhooks → Add endpoint:
//    URL: https://<project>.supabase.co/functions/v1/stripe-webhook
//    Events: customer.subscription.created, updated, deleted
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@14?target=deno'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
    apiVersion: '2024-06-20',
    httpClient: Stripe.createFetchHttpClient(),
})


// ── CORS Headers ─────────────────────────────────
const corsHeaders = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature',
};

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') {
        return new Response(null, { headers: corsHeaders });
    }

    const signature = req.headers.get('stripe-signature')
    const body      = await req.text()

    let event: Stripe.Event
    try {
        event = await stripe.webhooks.constructEventAsync(
            body, signature!, Deno.env.get('STRIPE_WEBHOOK_SECRET')!
        )
    } catch (err) {
        return new Response(`Webhook Error: ${err.message}`, { status: 400 })
    }

    const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    const sub = event.data.object as Stripe.Subscription
    const customerId = typeof sub.customer === 'string' ? sub.customer : sub.customer.id

    // Cari user dari customer ID
    const { data: existingSub } = await supabase
        .from('subscriptions')
        .select('user_id')
        .eq('stripe_customer_id', customerId)
        .single()

    if (!existingSub) {
        return new Response('Customer not found', { status: 404 })
    }

    const status  = sub.status === 'active' ? 'active' : sub.status === 'past_due' ? 'past_due' : 'inactive'
    const plan    = status === 'active' ? 'pro' : 'free'
    const periodEnd = new Date(sub.current_period_end * 1000).toISOString()

    await supabase.from('subscriptions').upsert([{
        user_id:            existingSub.user_id,
        stripe_customer_id: customerId,
        stripe_sub_id:      sub.id,
        status,
        plan,
        current_period_end: periodEnd,
        updated_at:         new Date().toISOString(),
    }], { onConflict: 'user_id' })

    // Hantar notifikasi kepada user
    if (event.type === 'customer.subscription.created' && status === 'active') {
        await supabase.from('notifications').insert([{
            user_id: existingSub.user_id,
            type:    'system',
            message: '⭐ SnapFlow Pro diaktifkan! Nikmati semua ciri premium.'
        }])
    }

    return new Response(JSON.stringify({ received: true }), {
        headers: { 'Content-Type': 'application/json' }
    })
})
