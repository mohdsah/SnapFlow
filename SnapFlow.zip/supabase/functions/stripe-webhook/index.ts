// ============================================================
//  SNAPFLOW — Stripe Webhook Handler
//  Verify signature + update DB selepas payment
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@14?target=deno'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
    apiVersion: '2024-06-20',
    httpClient: Stripe.createFetchHttpClient(),
})

const corsHeaders = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'content-type, stripe-signature',
}

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders })

    const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    try {
        // ✅ KRITIKAL: Verify Stripe signature
        const body      = await req.text()
        const signature = req.headers.get('stripe-signature')
        const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')

        if (!signature || !webhookSecret) {
            console.error('[webhook] Missing signature or secret')
            return new Response('Unauthorized', { status: 401 })
        }

        let event: Stripe.Event
        try {
            event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret)
        } catch (err) {
            console.error('[webhook] Signature verification failed:', err)
            return new Response('Invalid signature', { status: 400 })
        }

        console.log(`[webhook] Event: ${event.type}`)

        // ── Handle events ────────────────────────────────
        switch (event.type) {

            // ── Payment berhasil (subscription atau product) ──
            case 'checkout.session.completed': {
                const session = event.data.object as Stripe.Checkout.Session
                const meta    = session.metadata || {}
                const userId  = meta.user_id

                if (!userId) { console.error('[webhook] No user_id in metadata'); break }

                if (meta.type === 'pro_subscription') {
                    // Aktifkan Pro untuk 30 hari
                    const expiresAt = new Date(Date.now() + 30 * 24 * 3600000).toISOString()
                    await supabase.from('profiles').update({
                        is_pro:         true,
                        pro_expires_at: expiresAt
                    }).eq('id', userId)

                    await supabase.from('subscriptions').upsert([{
                        user_id: userId,
                        status:  'active',
                        plan:    'pro',
                        stripe_session_id: session.id,
                        current_period_end: expiresAt
                    }], { onConflict: 'user_id' })

                    // Log aktiviti
                    await supabase.from('audit_logs').insert({
                        user_id: userId, action: 'subscribe_pro',
                        details: { session_id: session.id }
                    })

                } else if (meta.type === 'product_checkout') {
                    const orderId = meta.order_id
                    if (orderId) {
                        // Update order status ke 'paid'
                        await supabase.from('orders').update({
                            status: 'paid',
                            stripe_session_id: session.id
                        }).eq('id', parseInt(orderId))

                        // Kurang stok produk
                        // (Stripe metadata has order info, fetch order items)
                        const { data: orderItems } = await supabase
                            .from('order_items')
                            .select('product_id, quantity')
                            .eq('order_id', orderId)

                        if (orderItems) {
                            for (const item of orderItems) {
                                await supabase.rpc('decrement_stock', {
                                    p_product_id: item.product_id,
                                    p_qty: item.quantity
                                })
                            }
                        }
                    }
                }
                break
            }

            // ── Subscription aktif ────────────────────────
            case 'customer.subscription.created':
            case 'customer.subscription.updated': {
                const sub    = event.data.object as Stripe.Subscription
                const custId = sub.customer as string

                const { data: dbSub } = await supabase
                    .from('subscriptions')
                    .select('user_id')
                    .eq('stripe_customer_id', custId)
                    .single()

                if (dbSub?.user_id) {
                    const isActive = sub.status === 'active'
                    const periodEnd = new Date(sub.current_period_end * 1000).toISOString()

                    await supabase.from('profiles').update({
                        is_pro: isActive, pro_expires_at: periodEnd
                    }).eq('id', dbSub.user_id)

                    await supabase.from('subscriptions').update({
                        status: sub.status,
                        current_period_end: periodEnd,
                        stripe_subscription_id: sub.id
                    }).eq('user_id', dbSub.user_id)
                }
                break
            }

            // ── Subscription tamat / dibatalkan ──────────
            case 'customer.subscription.deleted': {
                const sub    = event.data.object as Stripe.Subscription
                const custId = sub.customer as string

                const { data: dbSub } = await supabase
                    .from('subscriptions').select('user_id')
                    .eq('stripe_customer_id', custId).single()

                if (dbSub?.user_id) {
                    await supabase.from('profiles').update({
                        is_pro: false, pro_expires_at: null
                    }).eq('id', dbSub.user_id)

                    await supabase.from('subscriptions').update({
                        status: 'cancelled'
                    }).eq('user_id', dbSub.user_id)
                }
                break
            }

            // ── Payment gagal ─────────────────────────────
            case 'invoice.payment_failed': {
                const invoice = event.data.object as Stripe.Invoice
                const custId  = invoice.customer as string

                const { data: dbSub } = await supabase
                    .from('subscriptions').select('user_id')
                    .eq('stripe_customer_id', custId).single()

                if (dbSub?.user_id) {
                    // Notify user payment failed
                    await supabase.from('notifications').insert({
                        user_id: dbSub.user_id,
                        type: 'like', // reuse existing type
                        content: '⚠️ Bayaran Pro anda gagal. Sila kemaskini kad kredit.',
                    })
                }
                break
            }

            default:
                console.log(`[webhook] Unhandled event: ${event.type}`)
        }

        return new Response(JSON.stringify({ received: true }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })

    } catch (err: any) {
        console.error('[webhook] Error:', err)
        return new Response(JSON.stringify({ error: err.message }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
    }
})
