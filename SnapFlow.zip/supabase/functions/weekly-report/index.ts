// ============================================================
//  SNAPFLOW — Edge Function: Weekly Analytics Email
//  Deploy: npx supabase functions deploy weekly-report
//  Secrets: RESEND_API_KEY, APP_URL
//  Cron: 0 8 * * 1  (Isnin 8:00 pagi)
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'


// ── CORS Headers ─────────────────────────────────
const corsHeaders = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature',
};

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') {
        return new Response(null, { headers: corsHeaders });
    }

    const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );
    const RESEND_KEY = Deno.env.get('RESEND_API_KEY')!;
    const APP_URL    = Deno.env.get('APP_URL') || 'https://snapflow.netlify.app';

    let targetUserId: string | null = null;

    // Jika dipanggil manual oleh user, ambil user dari auth header
    const authHeader = req.headers.get('authorization');
    if (authHeader) {
        const token = authHeader.replace('Bearer ', '');
        const { data: { user } } = await supabase.auth.getUser(token);
        if (user) targetUserId = user.id;
    }

    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

    // Ambil semua creator atau satu user sahaja
    let userIds: string[] = [];
    if (targetUserId) {
        userIds = [targetUserId];
    } else {
        // Cron mode: ambil semua user yang ada video
        const { data: creators } = await supabase
            .from('videos').select('user_id').limit(200);
        userIds = [...new Set((creators || []).map(c => c.user_id))];
    }

    let sent = 0;

    for (const userId of userIds.slice(0, 50)) { // max 50 email sekali
        try {
            // Ambil data analytics
            const { data: videos } = await supabase
                .from('videos').select('id, caption, likes_count, created_at')
                .eq('user_id', userId).order('likes_count', { ascending: false }).limit(5);

            const { count: newFollowers } = await supabase
                .from('follows').select('*', { count: 'exact', head: true })
                .eq('following_id', userId).gt('created_at', weekAgo);

            const { data: gifts } = await supabase
                .from('gifts').select('coins_spent')
                .eq('receiver_id', userId).gt('created_at', weekAgo);

            const totalLikes   = (videos || []).reduce((s, v) => s + (v.likes_count || 0), 0);
            const totalViews   = totalLikes * 7; // anggaran
            const totalGiftCoins = (gifts || []).reduce((s, g) => s + (g.coins_spent || 0), 0);
            const topVideo     = videos?.[0];

            // Ambil email user dari auth
            const { data: { users } } = await supabase.auth.admin.listUsers();
            const authUser = users?.find(u => u.id === userId);
            if (!authUser?.email) continue;

            const userName = authUser.user_metadata?.full_name || 'Kreator';

            // HTML email
            const html = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#000;color:#fff;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
<div style="max-width:480px;margin:0 auto;padding:24px;">

  <!-- Header -->
  <div style="text-align:center;padding:30px 20px;background:linear-gradient(135deg,#fe2c55,#ff6b6b);border-radius:16px;margin-bottom:20px;">
    <h1 style="margin:0 0 6px;font-size:28px;font-weight:900;color:#fff;">SnapFlow</h1>
    <p style="margin:0;font-size:14px;color:rgba(255,255,255,0.8);">Laporan Mingguan Anda 📊</p>
  </div>

  <p style="color:#888;font-size:15px;">Hai <strong style="color:#fff;">${userName}</strong>! Ini ringkasan prestasi anda minggu ini:</p>

  <!-- Stats -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:20px 0;">
    ${[
        ['👁️', totalViews.toLocaleString(), 'Anggaran Views'],
        ['❤️', totalLikes.toLocaleString(), 'Jumlah Likes'],
        ['👥', (newFollowers || 0).toString(), 'Pengikut Baru'],
        ['🪙', totalGiftCoins.toLocaleString(), 'Syiling Diterima'],
    ].map(([icon, val, label]) => `
    <div style="background:#111;border:1px solid #222;border-radius:12px;padding:16px;text-align:center;">
        <div style="font-size:24px;margin-bottom:8px;">${icon}</div>
        <div style="font-size:24px;font-weight:900;color:#fff;">${val}</div>
        <div style="font-size:11px;color:#555;margin-top:4px;">${label}</div>
    </div>`).join('')}
  </div>

  <!-- Top Video -->
  ${topVideo ? `
  <div style="background:#111;border:1px solid #222;border-radius:12px;padding:16px;margin-bottom:16px;">
    <p style="margin:0 0 8px;font-size:11px;color:#555;text-transform:uppercase;letter-spacing:0.5px;font-weight:700;">🏆 VIDEO TERPOPULAR MINGGU INI</p>
    <p style="margin:0 0 6px;font-size:14px;font-weight:700;color:#fff;">${(topVideo.caption || 'Tanpa tajuk').slice(0, 60)}</p>
    <p style="margin:0;font-size:13px;color:#fe2c55;font-weight:700;">❤️ ${topVideo.likes_count || 0} likes</p>
  </div>` : ''}

  <!-- CTA -->
  <div style="text-align:center;margin:24px 0;">
    <a href="${APP_URL}/profile.html" style="background:#fe2c55;color:#fff;text-decoration:none;padding:14px 32px;border-radius:12px;font-size:15px;font-weight:800;display:inline-block;">
      Lihat Analitik Penuh →
    </a>
  </div>

  <!-- Tips -->
  <div style="background:#001a0a;border:1px solid #003a10;border-radius:12px;padding:16px;margin-bottom:20px;">
    <p style="margin:0 0 8px;font-size:13px;font-weight:800;color:#00f2ea;">💡 Tips Minggu Ini</p>
    <p style="margin:0;font-size:13px;color:#007a50;line-height:1.6;">
      ${(newFollowers || 0) > 5
        ? 'Tahniah! Pengikut anda bertambah minggu ini. Teruskan upload video berkualiti untuk mengekalkan momentum! 🚀'
        : 'Cuba upload video 3-5 kali seminggu dan gunakan hashtag trending untuk meningkatkan reach anda. Konsistensi adalah kunci! 🎯'}
    </p>
  </div>

  <!-- Footer -->
  <p style="text-align:center;font-size:12px;color:#333;margin:0;">
    © 2025 SnapFlow · <a href="${APP_URL}" style="color:#555;">Lawati App</a>
    · Anda menerima email ini kerana menggunakan SnapFlow
  </p>
</div>
</body>
</html>`;

            // Hantar email guna Resend API
            await fetch('https://api.resend.com/emails', {
                method:  'POST',
                headers: {
                    'Authorization': `Bearer ${RESEND_KEY}`,
                    'Content-Type':  'application/json',
                },
                body: JSON.stringify({
                    from:    'SnapFlow <laporan@snapflow.app>',
                    to:      [authUser.email],
                    subject: `📊 Laporan Mingguan SnapFlow — ${new Date().toLocaleDateString('ms-MY')}`,
                    html,
                })
            });

            sent++;
        } catch (err) {
            console.error(`Failed for user ${userId}:`, err.message);
        }
    }

    return new Response(JSON.stringify({ sent, timestamp: new Date().toISOString() }), {
        headers: { 'Content-Type': 'application/json' }
    });
});
