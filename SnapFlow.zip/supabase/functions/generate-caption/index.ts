// ============================================================
//  SNAPFLOW — Edge Function: AI Caption Generator (Claude API)
//  Deploy: npx supabase functions deploy generate-caption
//  Secret: ANTHROPIC_API_KEY
// ============================================================

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') {
        return new Response(null, {
            headers: {
                'Access-Control-Allow-Origin':  '*',
                'Access-Control-Allow-Methods': 'POST',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            }
        });
    }

    try {
        const formData  = await req.formData();
        const file      = formData.get('file') as File;

        let imageBase64 = '';
        let mediaType   = 'image/jpeg';

        // Jika video — tangkap frame (dalam produksi guna FFmpeg Lambda)
        // Untuk demo, terima gambar terus atau jana tanpa gambar
        if (file && file.type.startsWith('image/')) {
            const bytes   = await file.arrayBuffer();
            imageBase64   = btoa(String.fromCharCode(...new Uint8Array(bytes)));
            mediaType     = file.type as 'image/jpeg' | 'image/png' | 'image/webp';
        }

        const ANTHROPIC_KEY = Deno.env.get('ANTHROPIC_API_KEY')!;

        const messages: any[] = [{
            role: 'user',
            content: imageBase64 ? [
                {
                    type:   'image',
                    source: { type: 'base64', media_type: mediaType, data: imageBase64 }
                },
                {
                    type: 'text',
                    text: `Kamu adalah pakar media sosial Malaysia. Lihat video/gambar ini dan jana kapsyen menarik dalam Bahasa Melayu campur sikit English (Manglish) yang sesuai untuk TikTok/SnapFlow.

Jana:
1. Kapsyen menarik (1-2 ayat, maksimum 100 patah perkataan)
2. 5-8 hashtag trending yang relevan

Format jawapan HANYA JSON tanpa markdown:
{"caption": "kapsyen di sini", "hashtags": ["#tag1", "#tag2", "#tag3"]}`
                }
            ] : [
                {
                    type: 'text',
                    text: `Jana kapsyen video menarik dalam Bahasa Melayu campur English (Manglish) untuk platform video pendek seperti TikTok.

Jana kapsyen yang:
- Menarik perhatian dalam 2 ayat pertama
- Ada call-to-action
- Gunakan emoji secara natural
- Sesuai untuk trend Malaysia

Format jawapan HANYA JSON tanpa markdown:
{"caption": "kapsyen di sini", "hashtags": ["#viral", "#malaysia", "#snapflow", "#fyp", "#trending"]}`
                }
            ]
        }];

        const response = await fetch('https://api.anthropic.com/v1/messages', {
            method:  'POST',
            headers: {
                'Content-Type':      'application/json',
                'x-api-key':         ANTHROPIC_KEY,
                'anthropic-version': '2023-06-01',
            },
            body: JSON.stringify({
                model:      'claude-haiku-4-5-20251001',
                max_tokens: 400,
                messages,
            })
        });

        if (!response.ok) {
            throw new Error(`Claude API error: ${response.status}`);
        }

        const aiData  = await response.json();
        const rawText = aiData.content?.[0]?.text || '{}';

        let parsed: { caption?: string; hashtags?: string[] };
        try {
            parsed = JSON.parse(rawText.replace(/```json|```/g, '').trim());
        } catch {
            parsed = { caption: rawText, hashtags: ['#snapflow', '#viral', '#malaysia'] };
        }

        const caption   = parsed.caption   || '';
        const hashtags  = (parsed.hashtags || []).join(' ');
        const fullCaption = `${caption}\n\n${hashtags}`.trim();

        return new Response(JSON.stringify({ caption: fullCaption, success: true }), {
            headers: {
                'Content-Type':                'application/json',
                'Access-Control-Allow-Origin': '*',
            }
        });

    } catch (err) {
        return new Response(JSON.stringify({
            error:   err.message,
            caption: 'Video terbaru dari SnapFlow! 🔥 #viral #trending #malaysia #fyp #snapflow',
            success: false
        }), {
            status:  500,
            headers: {
                'Content-Type':                'application/json',
                'Access-Control-Allow-Origin': '*',
            }
        });
    }
});
