// ============================================================
//  SNAPFLOW — Edge Function: Secure Checkout
//  FIX: Price MESTI dari database, BUKAN dari frontend
//  Guna: npx supabase functions deploy create-checkout
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@14?target=deno'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
    apiVersion: '2024-06-20',
    httpClient: Stripe.createFetchHttpClient(),
})

const corsHeaders = {
    'Access-Control-Allow-Origin':  Deno.env.get('APP_URL') || '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// ── Helper: return JSON error ──
function errRes(msg: string, status = 400) {
    return new Response(JSON.stringify({ error: msg }), {
        status,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
}

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders })
    if (req.method !== 'POST') return errRes('Method not allowed', 405)

    try {
        // ── 1. Parse body ──────────────────────────────────
        const body = await req.json().catch(() => null)
        if (!body) return errRes('Invalid request body')

        const { type, userId, email } = body

        // ── 2. Verify user session (WAJIB) ────────────────
        const authHeader = req.headers.get('Authorization')
        if (!authHeader?.startsWith('Bearer ')) return errRes('Unauthorized', 401)

        const supabase = createClient(
            Deno.env.get('SUPABASE_URL')!,
            Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
        )

        // Verify JWT token
        const token = authHeader.replace('Bearer ', '')
        const { data: { user: authUser }, error: authErr } = await supabase.auth.getUser(token)
        if (authErr || !authUser) return errRes('Invalid session', 401)

        // Pastikan userId match dengan token
        if (authUser.id !== userId) return errRes('User mismatch', 403)

        // ── 3. Handle dua jenis checkout ──────────────────
        // A. SnapFlow Pro subscription
        if (type === 'pro_subscription') {
            // Price ID datang dari ENV var, BUKAN dari frontend
            const priceId = Deno.env.get('STRIPE_PRO_PRICE_ID')
            if (!priceId) return errRes('Pro price not configured', 500)

            // Semak jika sudah subscribe
            const { data: existingPro } = await supabase
                .from('profiles').select('is_pro, pro_expires_at').eq('id', userId).single()

            if (existingPro?.is_pro && existingPro.pro_expires_at > new Date().toISOString()) {
                return errRes('Anda sudah subscribe SnapFlow Pro.', 400)
            }

            // Dapatkan atau buat Stripe customer
            let { data: sub } = await supabase
                .from('subscriptions').select('stripe_customer_id').eq('user_id', userId).single()

            let customerId = sub?.stripe_customer_id
            if (!customerId) {
                const customer = await stripe.customers.create({
                    email: authUser.email,
                    metadata: { supabase_uid: userId }
                })
                customerId = customer.id
                await supabase.from('subscriptions').upsert([{
                    user_id: userId, stripe_customer_id: customerId,
                    status: 'inactive', plan: 'free'
                }], { onConflict: 'user_id' })
            }

            const session = await stripe.checkout.sessions.create({
                customer: customerId,
                mode: 'subscription',
                line_items: [{ price: priceId, quantity: 1 }],
                success_url: `${Deno.env.get('APP_URL')}/profile.html?pro=success`,
                cancel_url:  `${Deno.env.get('APP_URL')}/profile.html?pro=cancel`,
                allow_promotion_codes: true,
                metadata: { user_id: userId, type: 'pro_subscription' }
            })

            return new Response(JSON.stringify({ url: session.url }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            })
        }

        // B. Produk fizikal (shop)
        if (type === 'product_checkout') {
            const { items, shipping_address } = body // items = [{ product_id, qty }]

            if (!items?.length) return errRes('Cart kosong')
            if (!shipping_address?.name || !shipping_address?.address) {
                return errRes('Alamat penghantaran diperlukan')
            }

            // ✅ KRITIKAL: Ambil harga dari DATABASE, bukan dari frontend
            const productIds = items.map((i: any) => i.product_id)
            const { data: products, error: prodErr } = await supabase
                .from('products')
                .select('id, name, price, stock, image_url, is_active')
                .in('id', productIds)

            if (prodErr || !products?.length) return errRes('Produk tidak dijumpai')

            // Semak semua produk aktif dan ada stok
            const lineItems = []
            let serverTotal = 0

            for (const cartItem of items) {
                const product = products.find((p: any) => p.id === cartItem.product_id)
                if (!product) return errRes(`Produk ${cartItem.product_id} tidak dijumpai`)
                if (!product.is_active) return errRes(`${product.name} tidak lagi dijual`)
                if (product.stock < cartItem.qty) {
                    return errRes(`Stok tidak mencukupi untuk ${product.name}`)
                }

                // ✅ Harga dari DB, BUKAN dari frontend
                const unitPrice = Math.round(product.price * 100) // convert ke sen
                serverTotal += product.price * cartItem.qty

                lineItems.push({
                    price_data: {
                        currency: 'myr',
                        product_data: {
                            name: product.name,
                            images: product.image_url ? [product.image_url] : [],
                            metadata: { product_id: product.id }
                        },
                        unit_amount: unitPrice
                    },
                    quantity: cartItem.qty
                })
            }

            // Shipping (RM8 = 800 sen)
            const SHIPPING_COST = 800
            lineItems.push({
                price_data: {
                    currency: 'myr',
                    product_data: { name: 'Penghantaran Standard (3-5 hari)' },
                    unit_amount: SHIPPING_COST
                },
                quantity: 1
            })

            // Buat pending order dalam DB dulu
            const { data: order, error: orderErr } = await supabase
                .from('orders')
                .insert({
                    buyer_id: userId,
                    status: 'pending',
                    total_price: serverTotal + 8,
                    shipping_address: shipping_address,
                    // product_id akan di-update selepas webhook confirm
                })
                .select('id').single()

            if (orderErr) return errRes('Gagal buat pesanan', 500)

            const session = await stripe.checkout.sessions.create({
                mode: 'payment',
                line_items: lineItems,
                success_url: `${Deno.env.get('APP_URL')}/order-success.html?order=${order.id}`,
                cancel_url:  `${Deno.env.get('APP_URL')}/cart.html`,
                customer_email: authUser.email,
                metadata: {
                    user_id: userId,
                    order_id: order.id.toString(),
                    type: 'product_checkout'
                }
            })

            // Update order dengan stripe session ID
            await supabase.from('orders').update({
                stripe_session_id: session.id
            }).eq('id', order.id)

            return new Response(JSON.stringify({ url: session.url, order_id: order.id }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            })
        }

        return errRes('Jenis checkout tidak dikenali')

    } catch (err: any) {
        console.error('[checkout] Error:', err)
        return errRes(err.message || 'Server error', 500)
    }
})
