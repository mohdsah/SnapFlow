// ============================================================
//  SnapFlow — Edge Function: create-checkout
//  KRITIKAL: Harga MESTI dari database, BUKAN dari frontend
//  Deploy: npx supabase functions deploy create-checkout
// ============================================================

import Stripe from 'https://esm.sh/stripe@13.11.0?target=deno'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const errRes = (msg: string, status = 400) =>
    new Response(JSON.stringify({ error: msg }), {
        status,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
    if (req.method !== 'POST') return errRes('Method not allowed', 405)

    // ── 1. Verify JWT — pastikan request dari user yang sah ──────────
    const authHeader = req.headers.get('Authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return errRes('Unauthorized — sila log masuk', 401)
    }
    const token = authHeader.replace('Bearer ', '')

    const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_ANON_KEY')!,
    )
    const adminSupabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    )

    const { data: { user: authUser }, error: authErr } = await supabase.auth.getUser(token)
    if (authErr || !authUser) return errRes('Token tidak sah', 401)

    // ── 2. Parse request body ─────────────────────────────────────────
    let body: any
    try { body = await req.json() } catch { return errRes('Request body tidak sah') }

    const { type, userId, items, shipping_address } = body

    // ── 3. Pastikan userId = user yang login (WAJIB) ─────────────────
    if (!userId || userId !== authUser.id) {
        return errRes('User ID tidak sepadan — akses ditolak', 403)
    }

    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
        apiVersion: '2023-10-16',
        httpClient: Stripe.createFetchHttpClient(),
    })

    const origin = req.headers.get('origin') || Deno.env.get('APP_URL') || 'https://snapflow.netlify.app'

    try {
        // ────────────────────────────────────────────────────────────
        // ── CHECKOUT TYPE A: Langganan Pro ───────────────────────────
        // ────────────────────────────────────────────────────────────
        if (type === 'pro_subscription') {
            const priceId = Deno.env.get('STRIPE_PRO_PRICE_ID')
            if (!priceId) return errRes('Pro price tidak dikonfigurasi', 500)

            const session = await stripe.checkout.sessions.create({
                mode:                'subscription',
                payment_method_types: ['card'],
                line_items:          [{ price: priceId, quantity: 1 }],
                metadata:            { user_id: authUser.id, type: 'pro_subscription' },
                client_reference_id: authUser.id,
                success_url: `${origin}/order-success.html?session_id={CHECKOUT_SESSION_ID}&type=pro`,
                cancel_url:  `${origin}/index.html?cancelled=1`,
            })
            return new Response(JSON.stringify({ url: session.url }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            })
        }

        // ────────────────────────────────────────────────────────────
        // ── CHECKOUT TYPE B: Pembelian produk ────────────────────────
        // ────────────────────────────────────────────────────────────
        if (type === 'product_checkout') {
            if (!items || !Array.isArray(items) || items.length === 0) {
                return errRes('Tiada item dalam cart')
            }

            // Validate: maksimum 20 item jenis berbeza
            if (items.length > 20) return errRes('Terlalu banyak item berbeza')

            // ── KRITIKAL: Ambil harga dari DATABASE, bukan frontend ──
            const productIds = items.map((i: any) => i.product_id)
            const { data: products, error: prodErr } = await adminSupabase
                .from('products')
                .select('id, name, price, stock, image_url, is_active, seller_id')
                .in('id', productIds)

            if (prodErr) return errRes('Gagal semak produk: ' + prodErr.message, 500)
            if (!products || products.length === 0) return errRes('Produk tidak dijumpai')

            // ── Validate setiap item ─────────────────────────────────
            const lineItems: any[] = []
            let   serverTotal = 0

            for (const cartItem of items) {
                const qty = parseInt(cartItem.qty) || 1

                // Validate qty
                if (qty < 1 || qty > 99) {
                    return errRes(`Kuantiti tidak sah untuk produk #${cartItem.product_id}`)
                }

                const product = products.find((p: any) => p.id === cartItem.product_id)
                if (!product) {
                    return errRes(`Produk #${cartItem.product_id} tidak dijumpai`)
                }
                if (!product.is_active) {
                    return errRes(`Produk "${product.name}" tidak lagi dijual`)
                }
                if (product.stock < qty) {
                    return errRes(`Stok "${product.name}" tidak mencukupi (tersedia: ${product.stock})`)
                }

                // ✅ Guna harga dari DB — bukan dari frontend
                const unitPriceSen = Math.round(Number(product.price) * 100)
                if (unitPriceSen < 100) { // Minimum RM 1.00
                    return errRes(`Harga produk tidak sah`)
                }

                serverTotal += Number(product.price) * qty

                lineItems.push({
                    price_data: {
                        currency:     'myr',
                        product_data: {
                            name:   product.name,
                            images: product.image_url ? [product.image_url] : [],
                        },
                        unit_amount: unitPriceSen, // ✅ DARI DB, bukan frontend
                    },
                    quantity: qty,
                })
            }

            // Tambah penghantaran (server-side, bukan frontend)
            const SHIPPING_SEN = 800 // RM 8.00
            lineItems.push({
                price_data: {
                    currency:     'myr',
                    product_data: { name: 'Penghantaran Standard (3-5 hari bekerja)' },
                    unit_amount: SHIPPING_SEN,
                },
                quantity: 1,
            })

            // ── Buat order rekod dahulu ──────────────────────────────
            const { data: newOrder, error: orderErr } = await adminSupabase
                .from('orders')
                .insert({
                    buyer_id:        authUser.id,
                    status:          'pending_payment',
                    total_amount:    serverTotal,
                    shipping_amount: SHIPPING_SEN / 100,
                    shipping_address: shipping_address || null,
                })
                .select('id')
                .single()

            if (orderErr || !newOrder) {
                return errRes('Gagal buat order: ' + (orderErr?.message || 'unknown'), 500)
            }

            // Insert order items
            const orderItems = items.map((cartItem: any) => {
                const p = products.find((prod: any) => prod.id === cartItem.product_id)!
                return {
                    order_id:     newOrder.id,
                    product_id:   cartItem.product_id,
                    product_name: p.name,
                    quantity:     parseInt(cartItem.qty) || 1,
                    unit_price:   Number(p.price),
                    line_total:   Number(p.price) * (parseInt(cartItem.qty) || 1),
                }
            })
            await adminSupabase.from('order_items').insert(orderItems)

            // ── Buat Stripe Checkout Session ─────────────────────────
            const session = await stripe.checkout.sessions.create({
                mode:                'payment',
                payment_method_types: ['card'],
                line_items:          lineItems,
                metadata: {
                    user_id:  authUser.id,
                    order_id: String(newOrder.id),
                    type:     'product_checkout',
                },
                client_reference_id: authUser.id,
                success_url: `${origin}/order-success.html?session_id={CHECKOUT_SESSION_ID}&order_id=${newOrder.id}`,
                cancel_url:  `${origin}/cart.html?cancelled=1`,
            })

            // Update order dengan stripe session ID
            await adminSupabase
                .from('orders')
                .update({ stripe_session_id: session.id })
                .eq('id', newOrder.id)

            // Log audit
            await adminSupabase.from('audit_logs').insert({
                user_id: authUser.id,
                action:  'checkout_initiated',
                details: { order_id: newOrder.id, total: serverTotal, items: items.length },
                risk_level: 'low',
            }).catch(() => {}) // Non-critical

            return new Response(JSON.stringify({ url: session.url, order_id: newOrder.id }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            })
        }

        return errRes('Jenis checkout tidak dikenali')

    } catch (err: any) {
        console.error('[create-checkout] Error:', err)
        return errRes('Ralat server: ' + err.message, 500)
    }
})
