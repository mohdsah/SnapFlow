// ============================================================
//  SNAPFLOW — Edge Function: Create Stripe Checkout Session
//  Deploy: npx supabase functions deploy create-checkout
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@14?target=deno'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
    apiVersion: '2024-06-20',
    httpClient: Stripe.createFetchHttpClient(),
})


// ── CORS Headers ─────────────────────────────────
const corsHeaders = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature',
};

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') {
        return new Response(null, { headers: corsHeaders });
    }

    const { priceId, userId, email } = await req.json()

    const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Cari atau cipta Stripe customer
    let { data: existingSub } = await supabase
        .from('subscriptions').select('stripe_customer_id').eq('user_id', userId).single()

    let customerId = existingSub?.stripe_customer_id
    if (!customerId) {
        const customer = await stripe.customers.create({ email, metadata: { userId } })
        customerId = customer.id
        await supabase.from('subscriptions').upsert([{
            user_id: userId, stripe_customer_id: customerId,
            status: 'inactive', plan: 'free'
        }], { onConflict: 'user_id' })
    }

    const session = await stripe.checkout.sessions.create({
        customer:   customerId,
        mode:       'subscription',
        line_items: [{ price: priceId, quantity: 1 }],
        success_url: `${Deno.env.get('APP_URL')}/profile.html?pro=success`,
        cancel_url:  `${Deno.env.get('APP_URL')}/profile.html`,
        allow_promotion_codes: true,
    })

    return new Response(JSON.stringify({ url: session.url }), {
        headers: { 'Content-Type': 'application/json' }
    })
})
