// ============================================================
//  SKYNET — Edge Function: publish-scheduled
//  Cron: */5 * * * * (setiap 5 minit)
//  Pengesahan: CRON_SECRET header wajib
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-cron-secret',
}

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

    // ── Pengesahan: hanya Supabase cron yang boleh panggil ───────────
    const cronSecret  = req.headers.get('x-cron-secret')
    const serverSecret = Deno.env.get('CRON_SECRET')

    if (!serverSecret || !cronSecret || cronSecret !== serverSecret) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 401,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
    }

    const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    try {
        const now = new Date().toISOString()

        // Ambil video yang perlu diterbitkan
        const { data: toPublish, error } = await supabase
            .from('videos')
            .update({ is_published: true })
            .eq('is_published', false)
            .not('scheduled_at', 'is', null)
            .lte('scheduled_at', now)
            .select('id, user_id, caption, username')

        if (error) throw new Error('DB error: ' + error.message)

        const count = toPublish?.length || 0

        // Log audit untuk setiap video yang diterbitkan
        if (count > 0 && toPublish) {
            const logs = toPublish.map((v: any) => ({
                user_id:    v.user_id,
                action:     'video_auto_published',
                details:    { video_id: v.id, caption: v.caption?.substring(0, 50) },
                risk_level: 'low',
            }))
            await supabase.from('audit_logs').insert(logs).catch(() => {})
        }

        return new Response(JSON.stringify({
            success: true,
            published: count,
            timestamp: now,
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })

    } catch (err: any) {
        console.error('[publish-scheduled] Error:', err)
        return new Response(JSON.stringify({ error: err.message || 'Server error' }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
    }
})
